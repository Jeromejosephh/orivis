package com.example.orivis

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
